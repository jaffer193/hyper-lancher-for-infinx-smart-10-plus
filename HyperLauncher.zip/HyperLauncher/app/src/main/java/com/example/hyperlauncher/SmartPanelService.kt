package com.example.hyperlauncher

import android.app.ActivityOptions
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

// شريط خفيف على طرف الشاشة، وعند سحبه من الطرف تنزل لوحة كاملة فيها كل التطبيقات
class SmartPanelService : Service() {
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        showHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        removePanel()
        handle?.let { wm.removeView(it) }
        handle = null
        super.onDestroy()
    }

    private fun overlayParams(w: Int, h: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    // الشريط الصغير على الطرف الأيسر، يكفي تسحبه لليمين أو تضغط عليه
    private fun showHandle() {
        val view = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(0xAA7DF9FF.toInt())
            }
            var downX = 0f
            var opened = false
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        opened = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!opened && e.rawX - downX > dp(40)) {
                            opened = true
                            showPanel()
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!opened && abs(e.rawX - downX) < dp(10)) showPanel()
                    }
                    MotionEvent.ACTION_CANCEL -> opened = false
                }
                true
            }
        }
        val params = overlayParams(dp(12), dp(140)).apply {
            x = 0
            y = dp(260)
        }
        wm.addView(view, params)
        handle = view
    }

    private fun showPanel() {
        if (panel != null) return
        val pm = packageManager
        val white = 0xFFFFFFFF.toInt()

        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .sortedBy { it.first.lowercase() }

        // كل التطبيقات
        val grid = GridLayout(this).apply { columnCount = 4 }
        apps.forEach { (label, pkg) ->
            val icon = pm.getApplicationIcon(pkg)
            icon.setBounds(0, 0, dp(44), dp(44))
            val cell = TextView(this).apply {
                text = label
                setTextColor(white)
                textSize = 11f
                maxLines = 1
                gravity = android.view.Gravity.CENTER
                setCompoundDrawables(null, icon, null, null)
                compoundDrawablePadding = dp(6)
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnClickListener {
                    launchInWindow(pkg)
                    removePanel()
                }
            }
            grid.addView(cell)
        }

        // أزرار سريعة للإعدادات
        val shortcuts = listOf(
            "الإعدادات" to Settings.ACTION_SETTINGS,
            "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
            "البلوتوث" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "الصوت" to Settings.ACTION_SOUND_SETTINGS
        )
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), 0, dp(12), dp(12))
        }
        shortcuts.forEach { (name, action) ->
            val chip = TextView(this).apply {
                text = name
                setTextColor(white)
                textSize = 12f
                gravity = android.view.Gravity.CENTER
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(0x337DF9FF)
                }
                setPadding(dp(6), dp(10), dp(6), dp(10))
                setOnClickListener { openSettings(action) }
            }
            row.addView(chip, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(6)
            })
        }

        val header = TextView(this).apply {
            text = "✕ إغلاق   •   كل التطبيقات (${apps.size})"
            setTextColor(white)
            textSize = 14f
            setPadding(dp(16), dp(40), dp(16), dp(12))
            setOnClickListener { removePanel() }
        }

        val scroll = ScrollView(this).apply {
            setPadding(dp(8), 0, dp(8), dp(24))
            addView(grid)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF2101020.toInt())
            addView(header)
            addView(row)
            addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        val params = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        wm.addView(container, params)
        panel = container
    }

    private fun removePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    private fun openSettings(action: String) {
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        removePanel()
    }

    // يحاول يفتح التطبيق في نافذة صغيرة. بعض الأجهزة ما تدعم هالميزة، وحينها يفتح بملء الشاشة
    private fun launchInWindow(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK
        )
        val metrics = resources.displayMetrics
        val w = (metrics.widthPixels * 0.6).toInt()
        val h = (metrics.heightPixels * 0.4).toInt()
        val left = metrics.widthPixels - w - dp(16)
        val top = dp(120)
        val options = ActivityOptions.makeBasic().apply {
            launchBounds = Rect(left, top, left + w, top + h)
        }
        startActivity(intent, options.toBundle())
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
}
