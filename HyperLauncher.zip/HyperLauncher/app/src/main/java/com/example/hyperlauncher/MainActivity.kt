package com.example.hyperlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.launch

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Drawable
)

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, SmartPanelService::class.java))
        } else {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val activity = this@MainActivity
                val prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
                var setupDone by remember { mutableStateOf(prefs.getBoolean("setup_done", false)) }
                var columns by remember { mutableStateOf(prefs.getInt("columns", 4)) }
                var pinHash by remember { mutableStateOf(prefs.getString("pin_hash", "") ?: "") }
                var unlocked by remember { mutableStateOf(false) }
                var playingEffect by remember { mutableStateOf(false) }
                val biometricAvailable = remember {
                    BiometricManager.from(activity)
                        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
                        BiometricManager.BIOMETRIC_SUCCESS
                }
                val apps = remember { loadInstalledApps() }

                when {
                    !setupDone -> SetupScreen(
                        initialColumns = columns,
                        onFinish = { chosen, pin ->
                            val hash = hashPin(pin)
                            prefs.edit()
                                .putBoolean("setup_done", true)
                                .putInt("columns", chosen)
                                .putString("pin_hash", hash)
                                .apply()
                            columns = chosen
                            pinHash = hash
                            setupDone = true
                            unlocked = true
                        }
                    )
                    playingEffect -> UnlockEffect(onFinished = {
                        playingEffect = false
                        unlocked = true
                    })
                    !unlocked -> LockScreen(
                        pinHash = pinHash,
                        biometricAvailable = biometricAvailable,
                        onBiometric = { activity.promptBiometric { playingEffect = true } },
                        onUnlocked = { playingEffect = true }
                    )
                    else -> LauncherScreen(
                        apps = apps,
                        columns = columns,
                        onLaunch = { pkg -> launchApp(pkg) }
                    )
                }
            }
        }
    }

    private fun promptBiometric(onSuccess: () -> Unit) {
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("افتح HyperLauncher")
            .setNegativeButtonText("استخدم الرمز")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        prompt.authenticate(info)
    }

    // ما يفتح شاشة القفل ولا يتجاوز أي حماية، يشغّل التطبيقات بس
    private fun launchApp(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    private fun loadInstalledApps(): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm: PackageManager = packageManager
        return pm.queryIntentActivities(intent, 0)
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.loadIcon(pm)
                )
            }
            .filter { it.packageName != packageName }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
fun LauncherScreen(apps: List<AppInfo>, columns: Int, onLaunch: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var inGame by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(Modifier.fillMaxSize()) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1B2F), Color(0xFF0F0F1A))))
    ) {
        // المسافة من الأسفل: 0 يعني الدرج مفتوح، والارتفاع الكامل يعني مخفي
        val fullHeightPx = with(LocalDensity.current) { maxHeight.toPx() }
        val drawerY = remember { Animatable(fullHeightPx) }

        HomeScreen(
            apps = apps,
            columns = columns,
            onLaunch = onLaunch,
            onOpenGame = { inGame = true },
            modifier = Modifier.pointerInput(fullHeightPx) {
                detectVerticalDragGestures(
                    onVerticalDrag = { _, dragAmount ->
                        scope.launch {
                            drawerY.snapTo((drawerY.value + dragAmount).coerceIn(0f, fullHeightPx))
                        }
                    },
                    onDragEnd = {
                        scope.launch {
                            val target = if (drawerY.value < fullHeightPx / 2) 0f else fullHeightPx
                            drawerY.animateTo(
                                target,
                                spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
                            )
                        }
                    }
                )
            }
        )

        // درج التطبيقات ينزلق من الأسفل
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset { IntOffset(0, drawerY.value.toInt()) }
                .background(Color(0xE6000000))
        ) {
            AppDrawer(
                apps = apps.filter { it.label.contains(query, ignoreCase = true) },
                query = query,
                columns = columns,
                onQueryChange = { query = it },
                onLaunch = onLaunch
            )
        }
    }
    if (inGame) {
        SpaceGame(onExit = { inGame = false })
    }
    }
}

@Composable
fun HomeScreen(apps: List<AppInfo>, columns: Int, onLaunch: (String) -> Unit, onOpenGame: () -> Unit, modifier: Modifier = Modifier) {
    val pinned = apps.take(16)
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        modifier = modifier
            .fillMaxSize()
            .padding(top = 64.dp, start = 12.dp, end = 12.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item { GameTile(onClick = onOpenGame) }
        items(pinned) { app ->
            AppIcon(app = app, onClick = { onLaunch(app.packageName) })
        }
    }
}

@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    query: String,
    columns: Int,
    onQueryChange: (String) -> Unit,
    onLaunch: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 56.dp, start = 16.dp, end = 16.dp)
    ) {
        BasicTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp),
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x33FFFFFF), RoundedCornerShape(24.dp))
                .padding(horizontal = 16.dp, vertical = 12.dp)
        )
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(apps) { app ->
                AppIcon(app = app, onClick = { onLaunch(app.packageName) })
            }
        }
    }
}

@Composable
fun AppIcon(app: AppInfo, onClick: () -> Unit) {
    val bitmap = remember(app.packageName) { app.icon.toBitmap(128, 128).asImageBitmap() }
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = bitmap,
            contentDescription = app.label,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = app.label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
fun SetupScreen(initialColumns: Int, onFinish: (Int, String) -> Unit) {
    var columns by remember { mutableStateOf(initialColumns) }
    var pin by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1B2F), Color(0xFF0F0F1A))))
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "أهلاً بك في HyperLauncher",
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "اختار عدد الأعمدة في الشاشة الرئيسية",
            color = Color(0xB3FFFFFF),
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(3, 4, 5).forEach { n ->
                Button(onClick = { columns = n }) {
                    Text(if (columns == n) "✓ $n" else "$n")
                }
            }
        }
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
            label = { Text("اختار رمز من 4 أرقام") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = { onFinish(columns, pin) }, enabled = pin.length == 4) {
            Text("ابدأ")
        }
    }
}
