package com.example.hyperlauncher

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement as LayoutArrangement
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.MessageDigest

fun hashPin(pin: String): String =
    MessageDigest.getInstance("SHA-256")
        .digest(pin.toByteArray())
        .joinToString("") { "%02x".format(it) }

@Composable
fun LockScreen(
    pinHash: String,
    biometricAvailable: Boolean,
    onBiometric: () -> Unit,
    onUnlocked: () -> Unit
) {
    var entered by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (biometricAvailable) onBiometric()
    }
    LaunchedEffect(entered) {
        if (entered.length == 4) {
            if (hashPin(entered) == pinHash) {
                onUnlocked()
            } else {
                wrong = true
                entered = ""
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1B2F), Color(0xFF0F0F1A))))
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "أدخل الرمز",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = LayoutArrangement.spacedBy(16.dp)) {
            repeat(4) { i ->
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(if (i < entered.length) Color.White else Color(0x33FFFFFF))
                )
            }
        }
        if (wrong) {
            Spacer(Modifier.height(12.dp))
            Text(text = "الرمز غلط", color = Color(0xFFFF6B6B), fontSize = 14.sp)
        }
        Spacer(Modifier.height(24.dp))

        listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "⌫")
        ).forEach { keys ->
            Row(horizontalArrangement = LayoutArrangement.spacedBy(16.dp)) {
                keys.forEach { key ->
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(if (key.isEmpty()) Color.Transparent else Color(0x33FFFFFF))
                            .clickable(enabled = key.isNotEmpty()) {
                                wrong = false
                                entered = when {
                                    key == "⌫" -> entered.dropLast(1)
                                    entered.length < 4 -> entered + key
                                    else -> entered
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = key, color = Color.White, fontSize = 24.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (biometricAvailable) {
            Spacer(Modifier.height(12.dp))
            Button(onClick = onBiometric) { Text("استخدم البصمة") }
        }
    }
}
