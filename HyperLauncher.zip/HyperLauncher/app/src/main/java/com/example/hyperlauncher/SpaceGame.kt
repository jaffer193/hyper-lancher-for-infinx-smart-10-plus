package com.example.hyperlauncher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

// ---------- تأثير فتح القفل ----------

@Composable
fun UnlockEffect(onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(800, easing = FastOutSlowInEasing))
        onFinished()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F1A)),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(160.dp)
                .graphicsLayer {
                    val s = 0.5f + progress.value * 5f
                    scaleX = s
                    scaleY = s
                    alpha = 1f - progress.value
                }
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF7DF9FF), Color(0x007DF9FF))))
        )
    }
}

// ---------- زر اللعبة في الشاشة الرئيسية ----------

@Composable
fun GameTile(onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF3A0CA3), Color(0xFF4CC9F0)))),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "🚀", fontSize = 26.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = "SPACE GAME",
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

// ---------- قائمة داخل اللعبة ----------

@Composable
fun GameMenu(
    paused: Boolean,
    soundOn: Boolean,
    volume: Int,
    maxVolume: Int,
    brightness: Float,
    onTogglePause: () -> Unit,
    onToggleSound: () -> Unit,
    onVolume: (Int) -> Unit,
    onBrightness: (Float) -> Unit,
    onRestart: () -> Unit,
    onAppSettings: () -> Unit,
    onExit: () -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable(onClick = onClose)
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(270.dp)
                .background(Color(0xF0101020))
                .padding(20.dp)
                .pointerInput(Unit) { detectTapGestures { } }, // يمنع الضغط من إغلاق القائمة
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "القائمة",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Button(onClick = onTogglePause, modifier = Modifier.fillMaxWidth()) {
                Text(if (paused) "استئناف" else "إيقاف مؤقت")
            }
            Button(onClick = onRestart, modifier = Modifier.fillMaxWidth()) {
                Text("إعادة اللعب")
            }
            Button(onClick = onToggleSound, modifier = Modifier.fillMaxWidth()) {
                Text(if (soundOn) "الصوت: مفعّل" else "الصوت: مقفل")
            }

            Text(text = "الصوت العام: $volume / $maxVolume", color = Color.White, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onVolume(volume - 1) }, modifier = Modifier.weight(1f)) { Text("－") }
                Button(onClick = { onVolume(volume + 1) }, modifier = Modifier.weight(1f)) { Text("＋") }
            }

            val brightPercent = (brightness * 100).toInt()
            Text(text = "السطوع: $brightPercent%", color = Color.White, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onBrightness((brightness - 0.1f).coerceIn(0.05f, 1f)) },
                    modifier = Modifier.weight(1f)
                ) { Text("－") }
                Button(
                    onClick = { onBrightness((brightness + 0.1f).coerceIn(0.05f, 1f)) },
                    modifier = Modifier.weight(1f)
                ) { Text("＋") }
            }

            Spacer(Modifier.height(8.dp))
            Button(onClick = onAppSettings, modifier = Modifier.fillMaxWidth()) {
                Text("إدارة التطبيقات")
            }
            Button(onClick = onExit, modifier = Modifier.fillMaxWidth()) {
                Text("خروج من اللعبة")
            }
            Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
                Text("إغلاق القائمة")
            }
        }
    }
}

// ---------- اللعبة ----------

class Rock(var x: Float, var y: Float, val speed: Float, val radius: Float)

@Composable
fun SpaceGame(onExit: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    val tone = remember { runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 60) }.getOrNull() }
    DisposableEffect(Unit) {
        onDispose { tone?.release() }
    }

    val rocks = remember { mutableListOf<Rock>() }
    var ship by remember { mutableFloatStateOf(0.5f) }
    var score by remember { mutableIntStateOf(0) }
    var over by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var soundOn by remember { mutableStateOf(true) }
    var tick by remember { mutableLongStateOf(0L) }
    var restartKey by remember { mutableIntStateOf(0) }
    var volume by remember { mutableIntStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC)) }
    var brightness by remember {
        mutableFloatStateOf(
            activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f
        )
    }

    // حلقة اللعب: تتوقف مؤقتاً لما تكون القائمة مفتوحة أو اللعبة متوقفة
    LaunchedEffect(restartKey) {
        rocks.clear()
        score = 0
        over = false
        paused = false
        val rnd = java.util.Random()
        var last = 0L
        var spawnAcc = 0f
        while (!over) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 16f else ((now - last) / 1_000_000f).coerceAtMost(40f)
                last = now

                if (!paused && !menuOpen) {
                    spawnAcc += dt
                    if (spawnAcc > 650f) {
                        spawnAcc = 0f
                        rocks.add(
                            Rock(
                                x = rnd.nextFloat(),
                                y = -0.05f,
                                speed = 0.0004f + rnd.nextFloat() * 0.0005f,
                                radius = 0.03f + rnd.nextFloat() * 0.03f
                            )
                        )
                    }

                    val iter = rocks.iterator()
                    while (iter.hasNext()) {
                        val r = iter.next()
                        r.y += r.speed * dt
                        if (r.y > 1.1f) {
                            iter.remove()
                            score++
                            if (soundOn) tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 60)
                        } else if (r.y in 0.8f..0.92f && abs(r.x - ship) < r.radius + 0.05f) {
                            over = true
                            if (soundOn) tone?.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 300)
                        }
                    }
                }
                tick++
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF05050F))
            .pointerInput(Unit) {
                var edge = false
                var edgeTotal = 0f
                detectDragGestures(
                    onDragStart = { start ->
                        // السحب من الأطراف يفتح القائمة، والسحب من الوسط يحرك السفينة
                        edge = start.x < 60f || start.x > size.width - 60f
                        edgeTotal = 0f
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        if (edge) {
                            edgeTotal += amount.x
                            if (abs(edgeTotal) > 120f) {
                                menuOpen = true
                                edge = false
                            }
                        } else if (!menuOpen) {
                            ship = (change.position.x / size.width.toFloat()).coerceIn(0.05f, 0.95f)
                        }
                    },
                    onDragEnd = { edge = false },
                    onDragCancel = { edge = false }
                )
            }
            .pointerInput(over) {
                detectTapGestures(onTap = { if (over && !menuOpen) restartKey++ })
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val frame = tick // يجعل الرسم يتحدث كل إطار
            val w = size.width
            val h = size.height
            val cx = ship * w
            val cy = h * 0.86f
            val shipPath = Path().apply {
                moveTo(cx, cy - 40f)
                lineTo(cx - 30f, cy + 30f)
                lineTo(cx + 30f, cy + 30f)
                close()
            }
            drawPath(shipPath, color = Color(0xFF7DF9FF))
            rocks.forEach { r ->
                drawCircle(
                    color = Color(0xFF9E9E9E),
                    radius = r.radius * w,
                    center = Offset(r.x * w, r.y * h)
                )
            }
        }

        Text(
            text = if (paused) "النتيجة: $score (متوقفة)" else "النتيجة: $score",
            color = Color.White,
            fontSize = 18.sp,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 48.dp)
        )
        Text(
            text = "← رجوع",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .clickable(onClick = onExit)
        )
        Text(
            text = "⚙",
            color = Color.White,
            fontSize = 22.sp,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
                .clickable { menuOpen = true }
        )

        if (over && !menuOpen) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "انتهت اللعبة",
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { restartKey++ }) { Text("العب مرة ثانية") }
            }
        }

        if (menuOpen) {
            GameMenu(
                paused = paused,
                soundOn = soundOn,
                volume = volume,
                maxVolume = maxVolume,
                brightness = brightness,
                onTogglePause = { paused = !paused },
                onToggleSound = { soundOn = !soundOn },
                onVolume = { v ->
                    val c = v.coerceIn(0, maxVolume)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, c, AudioManager.FLAG_SHOW_UI)
                    volume = c
                },
                onBrightness = { b ->
                    brightness = b
                    activity?.window?.let { w ->
                        w.attributes = w.attributes.apply { screenBrightness = b }
                    }
                },
                onRestart = {
                    menuOpen = false
                    restartKey++
                },
                onAppSettings = {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                onExit = onExit,
                onClose = { menuOpen = false }
            )
        }
    }
}
